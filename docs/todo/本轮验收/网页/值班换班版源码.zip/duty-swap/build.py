import hashlib
from pathlib import Path
import shutil

root = Path(__file__).resolve().parent
src = root / 'src'
dist = root / 'dist'
assets = dist / 'assets'
assets.mkdir(parents=True, exist_ok=True)
html = (src / 'index.html').read_text(encoding='utf-8')
outputs = {
    'APP_JS': ('js', (root / 'vendor/vue.global.prod.js').read_bytes() + b'\n;\n' + (src / 'app.js').read_bytes()),
    'APP_CSS': ('css', (src / 'base.css').read_bytes() + b'\n' + (src / 'edit.css').read_bytes()),
}
for placeholder, (extension, data) in outputs.items():
    name = f'app-{hashlib.sha256(data).hexdigest()[:12]}.{extension}'
    (assets / name).write_bytes(data)
    html = html.replace(placeholder, f'./assets/{name}')
    for stale in assets.glob(f'app-*.{extension}'):
        if stale.name != name:
            stale.unlink()
(dist / 'index.html').write_text(html, encoding='utf-8')
shutil.copyfile(root / 'vendor/VUE-LICENSE.txt', dist / 'VUE-LICENSE.txt')
print('已生成 dist/')
