import argparse
from contextlib import closing
import json
from pathlib import Path
import sqlite3
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

ROOT = Path(__file__).resolve().parent
SEED = json.loads((ROOT / 'schedule.json').read_text(encoding='utf-8'))
DATES = {row['date'] for row in SEED}
PEOPLE = list(dict.fromkeys(row['primary'] for row in SEED))


def load(db):
    edits = dict(db.execute('SELECT day, person FROM primary_edits'))
    rows = [dict(row, primary=edits.get(row['date'], row['primary']),
                 initialPrimary=row['primary']) for row in SEED]
    for row, following in zip(rows, rows[1:]):
        if following['primary'] != following['initialPrimary']:
            row['handoff'] = following['primary']
            row['handoffUpdated'] = True
    revision, = db.execute('SELECT version FROM revision').fetchone()
    return {'rows': rows, 'people': PEOPLE, 'revision': revision}


def main():
    parser = argparse.ArgumentParser(description='交付小组本机换班服务')
    parser.add_argument('--port', type=int, default=8765)
    parser.add_argument('--db', type=Path, default=ROOT / 'data' / 'schedule.sqlite3')
    args = parser.parse_args()
    dist = ROOT / 'dist'
    if not (dist / 'index.html').is_file():
        parser.exit(2, '缺少 dist，请先运行 python3 build.py\n')
    db_path = args.db.resolve()
    db_path.parent.mkdir(parents=True, exist_ok=True)
    with closing(sqlite3.connect(db_path)) as db, db:
        db.execute('CREATE TABLE IF NOT EXISTS primary_edits (day TEXT PRIMARY KEY, person TEXT NOT NULL)')
        db.execute('CREATE TABLE IF NOT EXISTS revision (id INTEGER PRIMARY KEY CHECK(id=1), version INTEGER NOT NULL)')
        db.execute('INSERT OR IGNORE INTO revision VALUES (1, 0)')
    files = {'/': (dist / 'index.html', 'text/html; charset=utf-8')}
    for file in (dist / 'assets').iterdir():
        content_type = {'.js': 'text/javascript', '.css': 'text/css'}.get(file.suffix)
        if content_type and file.is_file():
            files[f'/assets/{file.name}'] = (file, f'{content_type}; charset=utf-8')

    class Handler(BaseHTTPRequestHandler):
        def reply(self, status, body, content_type):
            self.send_response(status)
            self.send_header('Content-Type', content_type)
            self.send_header('Content-Length', str(len(body)))
            self.send_header('Cache-Control', 'no-store')
            self.send_header('X-Content-Type-Options', 'nosniff')
            self.end_headers()
            self.wfile.write(body)

        def json(self, status, payload):
            self.reply(status, json.dumps(payload, ensure_ascii=False).encode(), 'application/json; charset=utf-8')

        def host_ok(self):
            return self.headers.get('Host') in {f'127.0.0.1:{self.server.server_port}', f'localhost:{self.server.server_port}'}

        def do_GET(self):
            if not self.host_ok():
                return self.json(403, {'error': '请通过本机地址访问。'})
            if self.path == '/api/schedule':
                try:
                    with closing(sqlite3.connect(db_path)) as db, db:
                        db.execute('BEGIN')
                        payload = load(db)
                    return self.json(200, payload)
                except sqlite3.Error:
                    return self.json(503, {'error': '读取排班失败，请重试。'})
            if self.path in files:
                file, content_type = files[self.path]
                return self.reply(200, file.read_bytes(), content_type)
            return self.json(404, {'error': '页面不存在。'})

        def do_POST(self):
            if not self.host_ok() or self.headers.get('Origin') not in (None, 'http://' + self.headers['Host']):
                return self.json(403, {'error': '请从本机排班页面提交。'})
            if self.path != '/api/schedule':
                return self.json(404, {'error': '接口不存在。'})
            if self.headers.get_content_type() != 'application/json':
                return self.json(415, {'error': '请使用 JSON 请求。'})
            try:
                size = int(self.headers.get('Content-Length', '0'))
                if not 0 < size <= 4096:
                    raise ValueError
                body = json.loads(self.rfile.read(size))
                if not isinstance(body, dict) or type(body.get('revision')) is not int:
                    raise ValueError
                day = body.get('date')
                action = body.get('action')
                person = body.get('person')
                other = body.get('otherDate')
                if not isinstance(day, str) or day not in DATES:
                    raise ValueError
                if action == 'replace' and person in PEOPLE:
                    pass
                elif action == 'swap' and isinstance(other, str) and other in DATES and other != day:
                    pass
                else:
                    raise ValueError
            except (ValueError, TypeError):
                return self.json(400, {'error': '请选择有效的日期或主值。'})
            try:
                with closing(sqlite3.connect(db_path)) as db, db:
                    db.execute('BEGIN IMMEDIATE')
                    state = load(db)
                    if body['revision'] != state['revision']:
                        return self.json(409, {'error': '排班已有更新，请重新选择。', **state})
                    current = {row['date']: row['primary'] for row in state['rows']}
                    changes = [(day, person)] if action == 'replace' else [(day, current[other]), (other, current[day])]
                    db.executemany('INSERT INTO primary_edits VALUES (?, ?) ON CONFLICT(day) DO UPDATE SET person=excluded.person', changes)
                    db.execute('UPDATE revision SET version=version+1 WHERE id=1')
                    payload = load(db)
                return self.json(200, payload)
            except sqlite3.Error:
                return self.json(503, {'error': '保存失败，请重试。'})

    with ThreadingHTTPServer(('127.0.0.1', args.port), Handler) as server:
        print(f'http://127.0.0.1:{server.server_port}/', flush=True)
        try:
            server.serve_forever()
        except KeyboardInterrupt:
            pass


if __name__ == '__main__':
    main()
