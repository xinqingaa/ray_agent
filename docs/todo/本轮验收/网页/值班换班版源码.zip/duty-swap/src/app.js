'use strict';

const dayFormatter = new Intl.DateTimeFormat('en-CA', {
  timeZone: 'Asia/Shanghai', year: 'numeric', month: '2-digit', day: '2-digit',
});

function beijingDate() {
  const parts = Object.fromEntries(dayFormatter.formatToParts(new Date()).map(part => [part.type, part.value]));
  return `${parts.year}-${parts.month}-${parts.day}`;
}

Vue.createApp({
  components: {
    DutyRoles: {
      props: ['row', 'variant'],
      template: `<dl :class="variant">
        <div><dt>主值</dt><dd>{{ row.primary }}</dd></div>
        <div><dt>备班</dt><dd>{{ row.backup }}</dd></div>
        <div><dt>交给谁</dt><dd>{{ row.handoff }}</dd></div>
      </dl>`,
    },
  },
  data() {
    return {
      rows: [], people: [], revision: 0, today: beijingDate(), selected: '',
      action: 'replace', person: '', other: '', loading: true, saving: false,
      message: '', error: '', timer: null,
    };
  },
  computed: {
    current() { return this.rows.find(row => row.date === this.selected); },
    todayRow() { return this.rows.find(row => row.date === this.today); },
    otherRows() { return this.rows.filter(row => row.date !== this.selected); },
    otherRow() { return this.otherRows.find(row => row.date === this.other); },
    dateMessage() {
      if (this.todayRow) return `今天是 ${this.today}（北京时间）。`;
      const status = this.today < this.rows[0].date ? '尚未开始' : '已结束';
      return `今天是 ${this.today}（北京时间），本排班周${status}。可选择日期查看或调整。`;
    },
    preview() {
      if (this.action === 'replace' && this.person) return `${this.dayLabel(this.current)}主值改为 ${this.person}。`;
      if (this.action === 'swap' && this.otherRow) {
        return `${this.dayLabel(this.current)}主值改为 ${this.otherRow.primary}，${this.dayLabel(this.otherRow)}主值改为 ${this.current.primary}。`;
      }
      return '';
    },
    backupNotice() {
      if (!this.preview) return '';
      const pairs = this.action === 'replace' ? [[this.current, this.person]] : [
        [this.current, this.otherRow.primary], [this.otherRow, this.current.primary],
      ];
      const overlaps = pairs.filter(([row, name]) => row.backup === name).map(([row]) => this.dayLabel(row));
      return overlaps.length ? `保存后，${overlaps.join('、')}的主值与备班为同一人。` : '';
    },
    canSave() { return this.preview && !this.saving; },
  },
  mounted() {
    this.loadSchedule();
    this.timer = setInterval(() => {
      const next = beijingDate();
      if (!this.saving && next !== this.today) {
        const wasToday = this.selected === this.today;
        this.today = next;
        if (wasToday && this.todayRow && !this.preview) this.choose(next);
      }
    }, 30000);
  },
  beforeUnmount() { clearInterval(this.timer); },
  methods: {
    dayLabel(row) {
      const [, month, day] = row.date.split('-');
      return `${Number(month)} 月 ${Number(day)} 日 ${row.day}`;
    },
    apply(data) {
      this.rows = data.rows;
      this.people = data.people;
      this.revision = data.revision;
    },
    choose(date) {
      this.selected = date;
      this.person = '';
      this.other = '';
      this.message = '';
      this.error = '';
    },
    async loadSchedule() {
      this.loading = true;
      this.error = '';
      try {
        const response = await fetch('/api/schedule');
        if (!response.ok) throw new Error();
        this.apply(await response.json());
        this.choose(this.todayRow?.date ?? this.rows[0].date);
      } catch {
        this.error = '无法读取排班。请确认 Python 服务已启动，然后重试。';
      } finally {
        this.loading = false;
      }
    },
    async save() {
      if (!this.canSave) return;
      this.saving = true;
      this.message = '';
      this.error = '';
      try {
        const response = await fetch('/api/schedule', {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            revision: this.revision, date: this.selected,
            action: this.action, person: this.person, otherDate: this.other,
          }),
        });
        const data = await response.json();
        if (response.status === 409) {
          this.apply(data);
          this.choose(this.selected);
        }
        if (!response.ok) throw new Error(data.error);
        this.apply(data);
        this.choose(this.selected);
        this.message = '换班已保存。';
      } catch (error) {
        this.error = error.message === 'Failed to fetch' || error instanceof SyntaxError
          ? '未能确认保存结果。请刷新排班后查看。' : error.message;
      } finally {
        this.saving = false;
      }
    },
  },
}).mount('#app');
